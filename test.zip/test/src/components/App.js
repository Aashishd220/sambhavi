import React, { useState } from 'react';
import DemoClass from './DemoClass'
import DemoFunction from './DemoFunction';

 const App=()=>{
     const[childTerm,setChildTerm]=useState('');
     const getTerm=(input)=>{
         console.log(input);
       setChildTerm(input);
     }
    return(
        <div>
            <h1>App</h1>
            <DemoClass keyTest="SambhaviClass" keyTest2="SambhaviClass" keyTest3="SambhaviClass"/>
            <DemoFunction keyTest1="AashishFuction" onGetTerm={getTerm}/>
            {`Term fetched from child component is ${childTerm}`}
        </div>
    )
}


export default App;