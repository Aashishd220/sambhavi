import React from "react";
import axios from 'axios'
class DemoClass extends React.Component {
    state={term:'sambhavi',term2:'chalegi'};

    // async componentDidMount(){
       
    //         const response= await axios.get('https://www.googleapis.com/books/v1/volumes?filter=free-ebooks&q=a');
    //        // console.log(response)
        
       
    // }
    // componentDidUpdate(){
    //    this.setState({term:'af'})
    // }
    
    clickMe=()=>{
        this.setState({term:'aashish' ,term2:'meri'})
    }
    
  render() {
    const {keyTest,keyTest2,keyTest3}=this.props;
    return <div>
        Class Component
      <h2> {this.state.term}</h2>
      <h2> {this.state.term2}</h2>

        {/* {this.props.keyTest} */}
        <button onClick={this.clickMe}>Click me</button>
        </div>;
  }
}

export default DemoClass;
