import React from 'react'

class Action extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to action Component</p>
            </div>
        )
    }
}

export default Action