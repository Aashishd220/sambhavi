import React from 'react'

class header extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to header Component</p>
                {this.props.data}
            </div>
        )
    }
}

export default header