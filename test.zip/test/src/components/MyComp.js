import React from 'react'
import Header from './Header'
import Footer from './Footer'
import Options from './Options'
import Adaoption from './Adoption'
import Action from './Action'


class myComp extends React.Component{
    render(){
        return(
            <div>
                <Header data="from mycomp to header"/>
                <p>Welcome to my child Component</p>
                <Action/>
                <Options/>
                <Adaoption/>


                <Footer/>
            </div>
        )
    }
}

export default myComp