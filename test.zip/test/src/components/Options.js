import React from 'react'
import Option from './Option'

class Options extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to Options Component</p>
                <Option/>
            </div>
        )
    }
}

export default Options