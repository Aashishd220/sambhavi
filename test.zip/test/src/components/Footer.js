import React from 'react'

class footer extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to footer Component</p>
            </div>
        )
    }
}

export default footer