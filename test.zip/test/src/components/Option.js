import React from 'react'

class Option extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to Option Component</p>
            </div>
        )
    }
}

export default Option