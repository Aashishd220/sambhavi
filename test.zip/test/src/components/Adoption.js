import React from 'react'

class Adaoption extends React.Component{
    render(){
        return(
            <div>
                <p>Welcome to Adaoption Component</p>
            </div>
        )
    }
}

export default Adaoption