import React, { useState,useEffect } from "react";
import axios from 'axios'
const DemoFunction = ({keyTest1,onGetTerm}) => {
    // const{keyTest1}=props

    const[term,setTerm]=useState('');
    const[term2,setTerm2]=useState(' ki kabhi nhi chalegi')
    // useEffect( ()=>{
    //     const fetchData=async ()=>{
    //         const response= await axios.get('https://www.googleapis.com/books/v1/volumes?filter=free-ebooks&q=a');
    //         console.log(response);
    //     }
    //     fetchData();
    // },[term])


    const clickMe=()=>{
        setTerm('sambhavi');
        setTerm2(' ki hamesha chalegi')
    }
    const inputChange=(e)=>{
        setTerm(e.target.value);
    }
    
    const handleSubmit=(event)=>{
        event.preventDefault();
        onGetTerm(term);
    }
  return <div>
      <form onSubmit={handleSubmit}>
     <input value={term} onChange={inputChange}/>
     </form>
     <h2>
         {term}
         {term2}
     </h2>
      <button onClick={clickMe}>Click Fuction</button>
  </div>;
};
export default DemoFunction;

//Class
 //define state={term:''};
     //update term='cricket' bad way
     //this.setState({term:'cricket'}) whenever we update the state, the component gets rerender
        // to rerender the component, we need to update the state
     //access {this.state.term}

//Function
 //define const[term,setTerm]=useState('aashish')
     //update term='cricket' bad way 
     //setTerm('sambhavi')
     //access {term}


    //  useEffect(()=>{
        
    // },[])

    //if the second argument is [], then it will act as componentDidMount
    //if there is no second argument, then it will run after the initial render and every time the component get rerendered
    //if the third argument is [term],then it will run after the initial render and every time the component get
    // rerendered and whenever the term changes