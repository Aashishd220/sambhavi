import React from 'react'
import SearchElement from './SearchElement'

const SearchList=({list,getVideo})=>{

    const renderedItem=list.map((item)=>{
        return(
            <div key={item.id.videoId}>
               <SearchElement item={item} searchGetVideo={getVideo}/>
            </div>
        )
    })
    
    return(
        <div>
           
           {renderedItem} 
          
            
        </div>
    )
}
export default SearchList;