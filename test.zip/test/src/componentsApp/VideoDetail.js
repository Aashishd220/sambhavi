import React from 'react'

const VideoDetail=({video})=> {
    if(!video){
        return<div>
            
        </div>;
    }
    return (
        <div>
            {`${video.id.videoId}-videoDetail`}   
        </div>
    )
}

export default VideoDetail
