import React, { useState } from 'react'
import SearchBar from './SearchBar';
import SearchList from './SearchList';
import youtube from '../apis/youtube';
import VideoDetail from './VideoDetail';

const App=()=>{
    const[value,setValue]=useState('');
    const [results,setResults]=useState([]);
    const[selectedVideo,setSelectedVideo]=useState(null);
    console.log(selectedVideo);

    const onGetVideo=(video)=>{
        setSelectedVideo(video);
    }

    const getValue=async (value)=>{
        console.log(value);
        const response= await youtube.get('/search',
        {
            params:{
             q:value,
             key:'AIzaSyAO4XDuGipRFNQH_wfzrFXPSXDWrqFAbA0'
            }
        })
       setResults(response.data.items);
    }
    return(
        <div > 
            
            <SearchBar getTerm={getValue}/>
            <SearchList list={results} getVideo={onGetVideo}/>
            <VideoDetail video={selectedVideo}/>

        </div>
    )
}
export default App;