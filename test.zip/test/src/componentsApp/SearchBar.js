import React, { useState } from "react";

const SearchBar = (props) => {
    const[term,setTerm]=useState('');
    const onHandleSubmit=(e)=>{
        e.preventDefault();
        props.getTerm(term);
       
    }
  return (
    <div className="input-group input-group-lg container">

        <form onSubmit={onHandleSubmit}>
      <input
        type="text"
        className="form-control"
        aria-label="Sizing example input"
        aria-describedby="inputGroup-sizing-lg"
        value={term}
        onChange={(e)=>{setTerm(e.target.value)}}        
      />
      </form>
    </div>
  );
};

export default SearchBar;
