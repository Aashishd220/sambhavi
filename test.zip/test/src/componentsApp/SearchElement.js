import React from "react";

const SearchElement = ({ item, searchGetVideo }) => {
  console.log(item);
  return (
    <div onClick={() => searchGetVideo(item)}>
      <h3> {item.id.videoId}</h3>
    </div>
  );
};

export default SearchElement;
