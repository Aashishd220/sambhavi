import React from 'react';
import logo from './logo.svg';
import './App.css';
import MyComp from './components/MyComp';

function App() {
  return (
    <div className="App">
     
      <h3>Welcome</h3>
      <MyComp/>
    </div>
  );
}

export default App;
