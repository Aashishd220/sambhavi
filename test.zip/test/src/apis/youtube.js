import axios from 'axios'
const KEY='AIzaSyAO4XDuGipRFNQH_wfzrFXPSXDWrqFAbA0'
export default axios.create({
    baseURL:'https://www.googleapis.com/youtube/v3/',
    params:{

        part:"snippet",
        type:'video',
        maxResults:5,
        key:'AIzaSyAO4XDuGipRFNQH_wfzrFXPSXDWrqFAbA0'
       }
       })