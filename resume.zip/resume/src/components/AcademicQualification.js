import React from "react";

function AcademicQualification({ information }) {
  return (
      <div className='mt-5'>
          <h4 className='textmiddle text-secondary'>ACADEMIC QUALIFICATION</h4>
      {information}
    </div>
  );
}

export default AcademicQualification;
