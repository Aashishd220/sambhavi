import React from "react";
import "./myStyle.css";
import Skills from "./Skills";
import WorkExperience from "./WorkExperience";
import AcademicQualification from "./AcademicQualification";
import Projects from "./Projects";
import Certificates from "./Certificates";
const App = () => {
  return (
    <div className="container mt-5 ">
      <div className="row">
        <div className="col-9">
          <h2 className="text-center text-secondary">Resume</h2>
          <h3 className="text-center text-secondary">Aashish Dhalla</h3>
          <AcademicQualification
            information="B-Tech. in Computer Science from Chandigarh Group of Colleges, Punjab Technical University, Chandigarh.
                                80%, 2018 Pass-out.
                                "
          />
          <WorkExperience
            date="July 2018-Present"
            designation="Senior Analyst at Capgemini Bangalore"
          />

          <Skills
            tools="Git, GitHub, WebMethods"
            database="MySQL, MongoDB(naive)"
            languages="C, C++, Java, SQL"
            webDevelopment="HTML, CSS, JavaScript, React JS, Node JS(naive), Express Framework"
          />

          <Projects
            prj1="Streaming Video App- React JS"
            prj2="Movie App- React JS"
            prj3="Weather App- Node JS"
            prj4="To-do REST API- Node JS"
          />
          <Certificates
            cert1="AWS Cloud Practioner Essentials (Second Edition)."
            cert2="DELL BOOMI ASSOCIATE DEVELOPER"
            cert3="DELL BOOMI PRODUCTION ADMINISTRATION"
          />
        </div>

        <div className="col-3">
          <img className="imgstyle" src="/aa.jpg" alt="not found" />
        </div>
      </div>
    </div>
  );
};

export default App;
