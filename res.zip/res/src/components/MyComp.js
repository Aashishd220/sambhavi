import React from 'react'

const MyComp=({heading,title1,title2,title3,title4,description1,description2,description3,description4})=>{
    return(
        <div>
            {heading}
            <br/>
            {title1? <div>{title1}:{description1}</div>:<div/>}
            <br/>
            {title2? <div>{title2}:{description2}</div>:<div/>}
            <br/>
             {title3? <div>{title3}:{description3}</div>:<div/>}
             <br/>
             {title4? <div>{title4}:{description4}</div>:<div/>}
             <br/>
        </div>
    )
}

export default MyComp