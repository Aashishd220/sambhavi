import React from "react";
import "./myStyle.css";
const Skills = ({ languages, tools, database, webDevelopment }) => {
    return (
        <div className='mt-5'>
            <h3 className='textmiddle text-secondary'><span className='m-5'>SKILLS</span></h3>
          <div className=" mt-3">
              <div className="container">
                  <div className="row">
                       <div className="col-4 " >Languages:</div>
                       <div className="col-8 ">{languages}</div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <div className="col-4 " >Web Development:</div>
                      <div className="col-8 ">{webDevelopment}</div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <div className="col-4 " >Database:</div>
                      <div className="col-8 "> {database}</div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <div className="col-4 " >Software/Tools:</div>
                      <div className="col-8 ">{tools}</div>
                  </div>
              </div>
             
    </div>
    </div>
  );
};

export default Skills;
