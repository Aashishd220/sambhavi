import React from "react";

const Certificates = ({ cert1, cert2, cert3 }) => {
  return (
      <div className='mt-5'>
          <h4 className='textmiddle text-secondary'><span className='m-5'>CERTIFICATES</span></h4>
      <ul>
        <li> {cert1}</li>
        <li> {cert2}</li>
        <li> {cert3}</li>
      </ul>
    </div>
  );
};

export default Certificates;
