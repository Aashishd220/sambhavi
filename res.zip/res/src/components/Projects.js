import React from "react";
import "./myStyle.css";
const Projects = ({ prj1, prj2, prj3, prj4 }) => {
  return (
    <div className='mt-5'>
          <h4 className='textmiddle text-secondary'><span className='m-5'>PROJECTS</span></h4>


          <div className=" mt-3">
              <div className="container">
                  <div className="row">
                      <div className="col-4 " > {prj1}</div>
                      <div className="col-8 "> <ul>
                          <li>
                              Developed an app to allow the user to stream videos like twitch using
                              OBS studio.
                           </li>
                          <li>
                              Implemented Redux, authentication, Redux Forms, REST API
                              functionality.
                            </li>
                      </ul></div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <div className="col-4" > {prj2}</div>
                      <div className="col-8 ">
                          <ul>
                              <li>
                                  Developed a light version of an IMDB style React Web Application.
                              </li>
                              <li>
                                  Used an API from the movie Database to get the required movie details
                              </li>
                          </ul>
                      </div>
                  </div>
              </div>
              <div className="container">
                  <div className="row">
                      <div className="col-4" > {prj3}</div>
                      <div className="col-8">
                          <ul>
                              <li>
                                  Developed a command line app that allows user to input address and the
                                  app shows the weather for that address.
                                </li>
                              <li>
                                  Used two API’s, first to get the coordinates of the input location and
                                  second to get the weather information.
                             </li>
                          </ul>

                      </div>
                  </div>
              </div>

          <div className="container">
              <div className="row">
                  <div className="col-4 " > {prj4}</div>
                  <div className="col-8 ">
                      <ul>
                          <li>
                              Developed a full-fledged REST API with user accounts and
                              authentication.
                            </li>
                          <li>
                              User can add, update, remove and read their to-dos from the database.
                             </li>
                      </ul> 

                  </div>
              </div>
          </div>
     </div>
    </div>
  );
};

export default Projects;
