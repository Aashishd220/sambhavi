import React, { useEffect } from "react";
import { connect } from "react-redux";
import { fetchBooks } from "../actions";
import Book from "./Book";

const BookList = (props) => {
  const book = props.books.map((book) => {
    return <Book key={book.id} book={book} />;
  });

  const { fetchBooks } = props;

  useEffect(() => {
    fetchBooks();
  }, []);

  return <div>{book}</div>;
};
const mapStateToProps = (state) => {
  return {
    books: state.bookReducer,
  };
};
export default connect(mapStateToProps, { fetchBooks })(BookList);
