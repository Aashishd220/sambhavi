import React from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import "../Book.css";
import BookList from "./BookList";

const BookDetail = ({ bookInfo }) => {
  // console.log(props.bookInfo.volumeInfo);
  if (!bookInfo) {
    return <BookList />;
  }
  return (
    <div className="card" style={{ width: "18rem" }}>
      <img
        src={bookInfo.volumeInfo.imageLinks.smallThumbnail}
        className="card-img-top"
        alt="image"
      />
      <div className="card-body">
        <h5 className="card-title">{bookInfo.volumeInfo.title}</h5>
        <p className="card-text">
          {bookInfo.volumeInfo.subtitle || `subtitle...`}
        </p>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => {
  return {
    bookInfo: state.selectedBookInfo,
  };
};
export default connect(mapStateToProps, {})(BookDetail);
