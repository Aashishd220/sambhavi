import React from "react";
import BookList from "./BookList";
import { BrowserRouter, Route, Link } from "react-router-dom";
import BookDetail from "./BookDetail";
import Header from "./Header";

const App = () => {
  return (
    <BrowserRouter>
      <Header />
      <Route path="/" exact component={BookList} />
      <Route path="/detail" exact component={BookDetail} />
    </BrowserRouter>
  );
};
export default App;
