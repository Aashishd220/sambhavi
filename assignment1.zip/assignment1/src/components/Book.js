import React from "react";
import { connect } from "react-redux";
import { selectedBook } from "../actions";
import BookDetail from "./BookDetail";
import { Link } from "react-router-dom";

const Book = (props) => {
  //    console.log(props.bookDetail);
  return (
    <div>
      <ul className="list-group">
        <li
          className="list-group-item"
          onClick={() => {
            props.selectedBook(props.book);
          }}
        >
          <Link to="/detail">{props.book.volumeInfo.title}</Link>
        </li>
      </ul>
    </div>
  );
};

const mapStateToProps = (state) => {
  //console.log(state.selectedBook)
  return {
    bookDetail: state.selectedBookInfo,
  };
};

export default connect(mapStateToProps, { selectedBook })(Book);
