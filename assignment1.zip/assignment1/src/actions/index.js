import axios from "axios";

export const FETCH_BOOKS = "FETCH_BOOKS";
export const SELECTED_BOOK = "SELECTED_BOOK";

export const fetchBooks = () => {
  return async (dispatch) => {
    const response = await axios.get(
      "https://www.googleapis.com/books/v1/volumes?filter=free-ebooks&q=a"
    );

    dispatch({
      type: FETCH_BOOKS,
      payload: response.data.items,
    });
  };
};

export const selectedBook = (book) => {
  return {
    type: SELECTED_BOOK,
    payload: book,
  };
};
