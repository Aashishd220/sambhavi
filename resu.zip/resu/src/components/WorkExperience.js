import React from "react";

const WorkExperience = ({ date, designation }) => {
  return (
    <div>
      <h4>WORK EXPERIENCE</h4>
      <span>
        {" "}
        {date} <b>{designation}</b>
      </span>
      <ul>
        <li>
          {" "}
          Had worked as a webmethods Developer, using SoftwareAG Designer for a
          client GE Aviation.{" "}
        </li>
        <li> Developed the interfaces using event driven architecture.</li>
        <li> Automated the monitoring process in MWS.</li>
        <li>
          {" "}
          Built Unit test plan and Integration test plan documents with sample
          Inputs provided from client.
        </li>
        <li>
          Created Business Required Documents and Technical Design Documents.
        </li>
        <li>Had supported the integrations in production environment.</li>
        <li>
          {" "}
          Had resolved the issues in the production environment by interacting
          with the application teams.
        </li>
      </ul>
    </div>
  );
};

export default WorkExperience;
