import React from "react";

const Projects = ({ prj1, prj2, prj3, prj4 }) => {
  return (
    <div>
      <h4>PROJECTS</h4>
      {prj1}
      <ul>
        <li>
          Developed an app to allow the user to stream videos like twitch using
          OBS studio.
        </li>
        <li>
          Implemented Redux, authentication, Redux Forms, REST API
          functionality.
        </li>
      </ul>

      {prj2}
      <ul>
        <li>
          Developed a light version of an IMDB style React Web Application.
        </li>
        <li>
          Used an API from the movie Database to get the required movie details
        </li>
      </ul>

      {prj3}
      <ul>
        <li>
          Developed a command line app that allows user to input address and the
          app shows the weather for that address.
        </li>
        <li>
          Used two API’s, first to get the coordinates of the input location and
          second to get the weather information.
        </li>
      </ul>

      {prj4}
      <ul>
        <li>
          Developed a full-fledged REST API with user accounts and
          authentication.
        </li>
        <li>
          User can add, update, remove and read their to-dos from the database.
        </li>
      </ul>
    </div>
  );
};

export default Projects;
