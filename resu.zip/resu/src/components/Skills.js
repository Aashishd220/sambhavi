import React from "react";

const Skills = ({ languages, tools, database, webDevelopment }) => {
  return (
    <div>
      <h3>SKILLS</h3>
      Languages:{languages}
      <br />
      Web Development:{webDevelopment}
      <br />
      Database: {database}
      <br />
      Software/Tools:{tools}
      <br />
    </div>
  );
};

export default Skills;
