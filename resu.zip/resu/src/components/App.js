import React from "react";
import MyComp from "./MyComp";
import Skills from "./Skills";
import WorkExperience from "./WorkExperience";
import AcademicQualification from "./AcademicQualification";
import Projects from "./Projects";
import Certificates from "./Certificates";
const App = () => {
  return (
    <div className="container">
      <h2 style={{ textAlign: "center" }}>Resume</h2>
      <h3 style={{ textAlign: "center" }}>Aashish Dhalla</h3>
      <AcademicQualification
        information="B-Tech. in Computer Science from Chandigarh Group of Colleges, Punjab     Technical University, Chandigarh.
        80%, 2018 Pass-out.
        "
      />
      <WorkExperience
        date="July 2018-Present"
        designation="Senior Analyst at Capgemini Bangalore"
      />

      <Skills
        tools="Git, GitHub, WebMethods"
        database="MySQL, MongoDB(naive)"
        languages="C, C++, Java, SQL"
        webDevelopment="HTML, CSS, JavaScript, React JS, Node JS(naive), Express Framework"
      />

      <Projects
        prj1="Streaming Video App- React JS"
        prj2="Movie App- React JS"
        prj3="Weather App- Node JS"
        prj4="To-do REST API- Node JS"
      />
      <Certificates
        cert1="AWS Cloud Practioner Essentials (Second Edition)."
        cert2="DELL BOOMI ASSOCIATE DEVELOPER"
        cert3="DELL BOOMI PRODUCTION ADMINISTRATION"
      />
    </div>
  );
};

export default App;
