import React from "react";

function AcademicQualification({ information }) {
  return (
    <div>
      <h4>ACADEMIC QUALIFICATION</h4>
      {information}
    </div>
  );
}

export default AcademicQualification;
