import React from "react";

const Certificates = ({ cert1, cert2, cert3 }) => {
  return (
    <div>
      <h4>CERTIFICATES</h4>
      <ul>
        <li> {cert1}</li>
        <li> {cert2}</li>
        <li> {cert3}</li>
      </ul>
    </div>
  );
};

export default Certificates;
